/*
 * statehandler.c
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#include "main.h"
#include "statehandler.h"

void Handler_IDLE(void)
{


}
void Handler_WARMUP(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET); // turn on Blue LED
	startSWTimer(eTimer3ID);
	vPrintString("warming up ...");
}

void Handler_FILLWATER(void)
{

}

void Handler_CUPSELECT(void)
{
	vPrintString("select cup size to continue ...");
}

void Handler_BREW(void)
{
	vPrintString("brewing ...");
	startSWTimer(eTimer1ID);
}

void Handler_SERVE(void)
{
	vPrintString("Coffee's ready. Enjoy!");
}

void Handler_OFF(void)
{
	vTurnOffLED(LD2_GPIO_Port, LD2_Pin);
	vTurnOffLED(GPIOD, LED4OZ_Pin);
	vTurnOffLED(GPIOD, LED8OZ_Pin);
	vTurnOffLED(GPIOD, LED12OZ_Pin);
	vTurnOffLED(GPIOD, LEDBREW_Pin);
}


