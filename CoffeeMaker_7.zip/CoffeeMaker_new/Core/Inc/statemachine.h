/*
 * statemachine.h
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#ifndef INC_STATEMACHINE_H_
#define INC_STATEMACHINE_H_

typedef enum {
	ST_OFF,
	ST_CHECKWATER,
	ST_WARMUP,
	ST_CUPSELECT,
	ST_BREW,
	ST_SERVE,

} state_enum_t;

typedef struct {
	state_enum_t currentState;
} stateMachine_t;

typedef enum {
	EV_ANY,
	EV_NONE,
	EV_PWR,
	EV_RESEVOIR_OK,
	EV_READY,
	EV_CUPSELECT,
	EV_BREWDONE,
	EV_TIMEROFF,
} sm_event_enum_t;

void StateMachine_Run(stateMachine_t * operation, sm_event_enum_t event);
void StateMachine_Init(stateMachine_t * operation);
state_enum_t sm_getCurrentState(stateMachine_t);

#endif /* INC_STATEMACHINE_H_ */
