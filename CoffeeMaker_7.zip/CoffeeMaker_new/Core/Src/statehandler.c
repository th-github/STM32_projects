/*
 * statehandler.c
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#include "main.h"
#include "statehandler.h"

void Handler_WARMUP(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, BLUE_LD2_Pin, GPIO_PIN_SET); // turn on Blue LED
	startSWTimer(TIMERID_WARMUP);
	vPrintString("warming up, wait ...");
}

void Handler_CHECKWATER(void)
{
	vPrintString("Handler_CHECKWATER");
}

void Handler_CUPSELECT(void)
{
	vPrintString("select cup size to continue ...");
}

void Handler_BREW(void)
{
	vPrintString("start brewing now ...");
	startSWTimer(TIMERID_BREW);
}

void Handler_SERVE(void)
{
	vPrintString("Coffee's ready. Enjoy!");
	vPrintString("New operation begin ...");
}

void Handler_OFF(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, BLUE_LD2_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
	vTurnOffLED(GPIOD, LED4OZ_Pin | LED8OZ_Pin | LED12OZ_Pin | LEDBREW_Pin);

	vPrintString("Power shutdown or AutoOff timer expired.");
}


