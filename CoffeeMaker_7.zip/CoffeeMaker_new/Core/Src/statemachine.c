/**
  ******************************************************************************
  * @file           : statemachine.c
  * @brief          : define data structure and behavior
  ******************************************************************************
*/

#include <statehandler.h>
#include "statemachine.h"

typedef struct {
    void (*pFunc)(void);
} stateHandlerGroup_t;

// order must be in sync with the order defined in state_enum_t for this array index
static stateHandlerGroup_t aStateHandler[] = {
		{(void*)&Handler_OFF},
		{(void*)&Handler_CHECKWATER},
		{(void*)&Handler_WARMUP},
		{(void*)&Handler_CUPSELECT},
		{(void*)&Handler_BREW},
		{(void*)&Handler_SERVE},

};

typedef struct {
	state_enum_t currentState;
	sm_event_enum_t currentEvent;
	state_enum_t nextState;
} stateTransitionMatrix_t;

static stateTransitionMatrix_t aStateTransitionMatrix[] = {
		{ST_OFF, 		EV_PWR, 			ST_CHECKWATER},

		{ST_CHECKWATER, EV_RESEVOIR_OK,		ST_WARMUP},

		{ST_WARMUP, 	EV_READY, 			ST_CUPSELECT},
		{ST_WARMUP, 	EV_PWR, 			ST_OFF},
		{ST_WARMUP, 	EV_TIMEROFF, 		ST_OFF},

		{ST_CUPSELECT, 	EV_CUPSELECT, 		ST_BREW},
		{ST_CUPSELECT, 	EV_PWR, 			ST_OFF},
		{ST_CUPSELECT, 	EV_TIMEROFF, 		ST_OFF},

		{ST_BREW, 		EV_BREWDONE, 		ST_SERVE},

		{ST_SERVE, 		EV_READY, 			ST_CHECKWATER},
		{ST_SERVE, 		EV_TIMEROFF, 		ST_OFF},
		{ST_SERVE, 		EV_PWR, 			ST_OFF},
};

void StateMachine_Init(stateMachine_t * operation)
{
	operation->currentState = ST_OFF;
}

state_enum_t sm_getCurrentState(stateMachine_t operation)
{
	return operation.currentState;
}

void StateMachine_Run(stateMachine_t * operation, sm_event_enum_t event)
{
	for (int i = 0; i < (int)(sizeof(aStateTransitionMatrix)/ sizeof(aStateTransitionMatrix[0])); i++)
	{
		if (aStateTransitionMatrix[i].currentState == operation->currentState) {
			if ((aStateTransitionMatrix[i].currentEvent == event) || (aStateTransitionMatrix[i].currentEvent == EV_ANY)) {
				operation->currentState = aStateTransitionMatrix[i].nextState;	// from current state to next state defined in the matrix
				(aStateHandler[operation->currentState].pFunc)();	// call the handler associated with the new state just transitioned to
				break;
			}
		}
	}
}

