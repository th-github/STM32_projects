/*
 * prptotype.h
 *
 *  Created on: Sep 27, 2021
 *      Author: admin
 */

#ifndef INC_PROTOTYPE_H_
#define INC_PROTOTYPE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include "stm32f7xx_hal.h"

/* USER CODE BEGIN Private defines */
#define SensorWater_Pin GPIO_PIN_2
#define SensorWater_GPIO_Port GPIOD
#define SensorWater_EXTI_IRQn EXTI15_10_IRQn
#define BtnBrew_Pin GPIO_PIN_11
#define BtnBrew_GPIO_Port GPIOC
#define BtnBrew_EXTI_IRQn EXTI15_10_IRQn
#define BtnAutoOff_Pin GPIO_PIN_12
#define BtnAutoOff_GPIO_Port GPIOC
#define BtnAutoOff_EXTI_IRQn EXTI15_10_IRQn
#define BTN4OZ_Pin GPIO_PIN_8
#define BTN4OZ_GPIO_Port GPIOC
#define BTN8OZ_Pin GPIO_PIN_9
#define BTN8OZ_GPIO_Port GPIOC
#define BTN12OZ_Pin GPIO_PIN_2
#define BTN12OZ_GPIO_Port GPIOG
#define BTNBREW_Pin GPIO_PIN_11
#define BTNBREW_GPIO_Port GPIOC
#define BTNAUTO_Pin GPIO_PIN_12
#define BTNAUTO_GPIO_Port GPIOC
#define LED4OZ_Pin GPIO_PIN_7
#define CUPSELECT_Port GPIOD
#define LED8OZ_Pin GPIO_PIN_6
#define LED12OZ_Pin GPIO_PIN_5
#define LEDBREW_Pin GPIO_PIN_4
#define LEDBREW_GPIO_Port GPIOD
#define LEDWATER_Pin GPIO_PIN_3
#define LEDWATER_GPIO_Port GPIOD

/* USER CODE END Private defines */


void proto_TurnOnLED(GPIO_TypeDef* port, uint16_t pin);
void proto_TurnOffLED(GPIO_TypeDef* port, uint16_t pin);

#ifdef __cplusplus
}
#endif

#endif /* INC_PROTOTYPE_H_ */
