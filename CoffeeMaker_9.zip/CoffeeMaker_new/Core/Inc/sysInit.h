/*
 * sysInit.h
 *
 *  Created on: Sep 27, 2021
 *      Author: thua
 *      INCLUDE THIS MODULE ONLY IN MAIN.C
 */

#ifndef INC_SYSINIT_H_
#define INC_SYSINIT_H_

#ifdef __cplusplus
extern "C" {
#endif


extern PCD_HandleTypeDef hpcd_USB_OTG_FS;


void SystemClock_Config(void);
void MX_USB_OTG_FS_PCD_Init(void);
void MX_GPIO_Init(void);


#ifdef __cplusplus
}
#endif

#endif /* INC_SYSINIT_H_ */
