/*
 * usart.h
 *
 *  Created on: Sep 27, 2021
 *      Author: thua
 */

#ifndef INC_USART_H_
#define INC_USART_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"
UART_HandleTypeDef usart_getusartHandle(void);

UART_HandleTypeDef MX_USART_UART_Init();

void usart_vPrintString(char* pvInBuf);

#ifdef __cplusplus
}
#endif

#endif /* INC_USART_H_ */
