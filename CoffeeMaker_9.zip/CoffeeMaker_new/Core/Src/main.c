/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "prototype.h"
#include "main.h"
#include "cmsis_os.h"
#include "sysInit.h"
#include "usart.h"
#include "statemachine.h"
#include "statehandler.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
	eNone = 0,
	eStrongBrew,
	eNormalBrew,
	eAutoOff,
	eManualOff,
	ePowerOn,
	ePowerOff,
} option_t;
#define OPTIONS_MAX 10
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
static UART_HandleTypeDef hUSART;	// obtained from usart.c module

osThreadId defaultTaskHandle;
osThreadId OptionButtonHandle;
osThreadId SizeSelectHandle;
osThreadId PowerCtrlHandle;
osThreadId WaterCtrlHandle;
osThreadId StartHandle;
osSemaphoreId myBinarySem01Handle;
/* USER CODE BEGIN PV */
TaskHandle_t BrewTaskHandle;
EventGroupHandle_t xEventGroup;

static stateMachine_t sm_obj;
static TimerHandle_t xTimers[3];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

/* USER CODE BEGIN PFP */
static void createTasks(void);
void Task_Default(void const * argument);
void Task_OptionBtn(void const * argument);
void Task_SizeSelect(void const * argument);
void Task_PowerCtrl(void const * argument);
void Task_WaterCtrl(void const * argument);
void StartTask(void const * argument);

void prvBrewTimerCallback(xTimerHandle xTimer);
void prvAutoOffTimerCallback(xTimerHandle xTimer);
void prvWarmupTimerHandler(xTimerHandle xTimer);


void startSWTimer(timerID_t timerID)
{
	if (xTimerStart(xTimers[timerID], 0) != pdPASS) {
		usart_vPrintString("xTimerStart Error!");
		return;
	}
	usart_vPrintString("xTimer started");

}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



/**
  * @brief  The task triggered by the software timer interrupt.
  * @retval void
  */
void prvBrewTimerCallback(xTimerHandle xTimer)
{	// note: do NOT call blocking function in SW timer task
	// somehow previously this timer task did not get started until I raised the timer task priority from 2 to 3!
	usart_vPrintString("Finished brewing.");
	StateMachine_Run(&sm_obj, EV_BREWDONE);
}

/**
  * @brief  The task triggered by the software timer interrupt.
  * @retval void
  */
void prvAutoOffTimerCallback(xTimerHandle xTimer)
{	// note: do NOT call blocking function in SW timer task
	usart_vPrintString("AutoOffTimer triggered.");
	StateMachine_Run(&sm_obj, EV_TIMEROFF);

}

/**
  * @brief  The task triggered by the software timer interrupt.
  * @retval void
  */
void prvWarmupTimerCallback(xTimerHandle xTimer)
{
	usart_vPrintString("Water warmed up.");
	StateMachine_Run(&sm_obj, EV_READY);
	HAL_GPIO_WritePin(LD2_GPIO_Port, BLUE_LD2_Pin, GPIO_PIN_SET); // turn on Blue LED

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	xEventGroup = xEventGroupCreate();
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();

  hUSART = MX_USART_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  /* USER CODE BEGIN 2 */

  StateMachine_Init(&sm_obj);

  eOption = eNONE;	// option keys press
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);	// turn it off

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of myBinarySem01 */
  osSemaphoreDef(myBinarySem01);
  myBinarySem01Handle = osSemaphoreCreate(osSemaphore(myBinarySem01), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  createTasks();

  /* USER CODE BEGIN RTOS_THREADS */
  	xTimers[TIMERID_BREW] = xTimerCreate("OneShot1", pdMS_TO_TICKS(BREWTIMER), pdFALSE,
  								(void*)TIMERID_BREW, prvBrewTimerCallback);

	xTimers[TIMERID_AUTOOFF] = xTimerCreate("OneShot2", pdMS_TO_TICKS(AUTOOFFTIMER), pdFALSE,
								(void*)TIMERID_AUTOOFF, prvAutoOffTimerCallback);
	xTimers[TIMERID_WARMUP] = xTimerCreate("OneShot2", pdMS_TO_TICKS(WARMUPTIMER), pdFALSE,
								(void*)TIMERID_WARMUP, prvWarmupTimerCallback);
	if (xTimers[TIMERID_BREW] == NULL || xTimers[TIMERID_AUTOOFF] == NULL || xTimers[TIMERID_WARMUP] == NULL)
		usart_vPrintString("xTimers[] not created.");


  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */
static void createTasks(void)
{
	  /* definition and creation of defaultTask */
	  osThreadDef(defaultTask, Task_Default, osPriorityNormal, 0, 128);
	  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

	  /* definition and creation of OptionButton */
	  osThreadDef(OptionButton, Task_OptionBtn, osPriorityBelowNormal, 0, 128);
	  OptionButtonHandle = osThreadCreate(osThread(OptionButton), NULL);

	  /* definition and creation of SizeSelect */
	  osThreadDef(SizeSelect, Task_SizeSelect, osPriorityNormal, 0, 128);
	  SizeSelectHandle = osThreadCreate(osThread(SizeSelect), NULL);

	  /* definition and creation of PowerCtrl */
	  osThreadDef(PowerCtrl, Task_PowerCtrl, osPriorityNormal, 0, 128);
	  PowerCtrlHandle = osThreadCreate(osThread(PowerCtrl), NULL);

	  /* definition and creation of PowerCtrl */
	  osThreadDef(WaterCtrl, Task_WaterCtrl, osPriorityNormal, 0, 128);
	  WaterCtrlHandle = osThreadCreate(osThread(WaterCtrl), NULL);

	  /* definition and creation of Start */
	  osThreadDef(Start, StartTask, osPriorityNormal, 0, 128);
	  StartHandle = osThreadCreate(osThread(Start), NULL);
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_Task_Default */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Task_Default */
void Task_Default(void const * argument)
{
  /* USER CODE BEGIN 5 */
	uint8_t dWaitState = 0;

  /* Infinite loop */
  for(;;)
  {
	  if (sm_obj.currentState == ST_CHECKWATER)
	  {
		  if (HAL_GPIO_ReadPin(SensorWater_GPIO_Port, SensorWater_Pin) != 0)
		  {
			  HAL_GPIO_TogglePin(LD3_GPIO_Port, GPIO_PIN_14);
			  dWaitState++;
			  dWaitState &= 3;	// keep reminder every 2 sec.
			  if (dWaitState == 0)
				  usart_vPrintString("Please fill water ...");
		  }
		  else {
			  HAL_GPIO_WritePin(LD3_GPIO_Port, GPIO_PIN_14, GPIO_PIN_RESET);	// water level OK. Turn off the water LED
			  xEventGroupSetBits(xEventGroup, EVENTGROUPBIT_FILLWATER);	// ok to repeat this every half seconds?
		  }

	  }
	  else if (sm_obj.currentState == ST_SERVE)
	  {
		  StateMachine_Run(&sm_obj, EV_READY);	// transition to ST_CHECKWATER
	  }

	  osDelay(500);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_Task_OptionBtn */
/**
* @brief Function implementing the OptionButton thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task_OptionBtn */
void Task_OptionBtn(void const * argument)
{
  /* USER CODE BEGIN Task_OptionBtn */
	option_t eCurrentChoice = eManualOff;

  /* Infinite loop */
  for(;;)
  {
	  if ((sm_obj.currentState == ST_SERVE || sm_obj.currentState == ST_CUPSELECT) &&
			  eOption == eAUTOOFF)
	  {
		  if (eCurrentChoice == eManualOff) {
			  eCurrentChoice = eAUTOOFF;
			  usart_vPrintString("AutoOff Timer is now set.");
			  xTimerStart(xTimers[1], 0);
		  }
		  else {
			  eCurrentChoice = eManualOff;
			  xTimerStop(xTimers[1], 0);
			  HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);	// turn off
			  usart_vPrintString("AutoOff Timer is aborted.");
		  }
		  eOption = eNONE;
	  }

	  if (xTimerIsTimerActive(xTimers[1]))
		  HAL_GPIO_TogglePin(LD1_GPIO_Port, LD1_Pin);
    osDelay(1000);
  }
  /* USER CODE END Task_OptionBtn */
}

/* USER CODE BEGIN Header_Task_SizeSelect */
/**
* @brief Function implementing the SizeSelect thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task_SizeSelect */
void Task_SizeSelect(void const * argument)
{
  /* USER CODE BEGIN Task_SizeSelect */
	BaseType_t sequence = 0;
	bool bSizeSelected = false;
	bool bStrongBrew = false;
  /* Infinite loop */
  for(;;)
  {
	 if (sm_obj.currentState != ST_CUPSELECT) {
		 osDelay(150);
		 continue;
	 }

	  if (eOption == eBREW)
	  {
			  if (bStrongBrew == false) {
				  usart_vPrintString("Strong brew");
				  HAL_GPIO_WritePin(LEDBREW_GPIO_Port, LEDBREW_Pin, GPIO_PIN_RESET);	// turn on
				  bStrongBrew = true;
			  }
			  else {
				  usart_vPrintString("Regular brew");
				  HAL_GPIO_WritePin(LEDBREW_GPIO_Port, LEDBREW_Pin, GPIO_PIN_SET);		// turn off
				  bStrongBrew = false;
			  }
			  eOption = eNONE;
	  }
	  switch (sequence)
	  {
	  case 2:
		  if(HAL_GPIO_ReadPin(BTN4OZ_GPIO_Port, BTN4OZ_Pin) == 1)
		  {
			  proto_TurnOffLED(CUPSELECT_Port, LED12OZ_Pin);
			  proto_TurnOffLED(CUPSELECT_Port, LED8OZ_Pin);
			  proto_TurnOnLED(CUPSELECT_Port, LED4OZ_Pin);
			  usart_vPrintString("4 Oz");
			  bSizeSelected = true;
		  }

		  sequence = 3;
		  break;
	  case 1:
		  if(HAL_GPIO_ReadPin(BTN8OZ_GPIO_Port, BTN8OZ_Pin) == 1)
		  {
			  proto_TurnOffLED(CUPSELECT_Port, LED12OZ_Pin);
			  proto_TurnOffLED(CUPSELECT_Port, LED4OZ_Pin);
			  proto_TurnOnLED(CUPSELECT_Port, LED8OZ_Pin);
			  usart_vPrintString("8 Oz");
			  bSizeSelected = true;
		  }
		  sequence = 2;
		  break;
	  case 0:
		  if(HAL_GPIO_ReadPin(BTN12OZ_GPIO_Port, BTN12OZ_Pin) == 1)
		  {
			  proto_TurnOffLED(CUPSELECT_Port, LED4OZ_Pin);
			  proto_TurnOffLED(CUPSELECT_Port, LED8OZ_Pin);
			  proto_TurnOnLED(CUPSELECT_Port, LED12OZ_Pin);
			  usart_vPrintString("12 Oz");
			  bSizeSelected = true;
		  }
		  sequence = 1;

		  break;
	  default:
		  if (sm_obj.currentState == ST_CUPSELECT && bSizeSelected == false)
		  {
			  HAL_GPIO_TogglePin(CUPSELECT_Port, LED4OZ_Pin | LED8OZ_Pin | LED12OZ_Pin);
		  }
		  sequence = 0;
		  break;
	  }
	  if (bSizeSelected == true) {
		  sequence = 0;
		  bSizeSelected = false;
		  xEventGroupSetBits(xEventGroup, EVENTGROUPBIT_CUPSELECT);

	  }

    osDelay(150);
  }
  /* USER CODE END Task_SizeSelect */
}

/* USER CODE BEGIN Header_Task_PowerCtrl */
/**
* @brief Function implementing the PowerCtrl thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task_PowerCtrl */
void Task_PowerCtrl(void const * argument)
{
  /* USER CODE BEGIN Task_PowerCtrl */
	usart_vPrintString(" -- Welcome! Coffee Lover -- ");
  /* Infinite loop */
  for(;;)
  {
	xEventGroupWaitBits(xEventGroup, EVENTGROUPBIT_POWER, pdTRUE,	// clear the bit on exit
			pdFALSE, 	// wait for this bit only
			portMAX_DELAY);	// wait here until the power button press is detected

	HAL_GPIO_WritePin(LD2_GPIO_Port, BLUE_LD2_Pin, GPIO_PIN_SET); // turn on Blue LED
	StateMachine_Run(&sm_obj, EV_PWR);	// transition to ST_CHECKWATER

    osDelay(500);
  }
  /* USER CODE END Task_PowerCtrl */
}

/* USER CODE BEGIN Header_Task_PowerCtrl */
/**
* @brief Function implementing the WaterCtrl thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Task_WaterCtrl */
void Task_WaterCtrl(void const * argument)
{
  /* USER CODE BEGIN Task_PowerCtrl */

  /* Infinite loop */
  for(;;)
  {
	xEventGroupWaitBits(xEventGroup, EVENTGROUPBIT_FILLWATER, pdTRUE,	// clear the bit on exit
			pdFALSE, 	// wait for this bit only
			portMAX_DELAY);	// wait here until the power button press is detected

	StateMachine_Run(&sm_obj, EV_RESEVOIR_OK);	// transition to ST_WARMUP

    osDelay(500);
  }
  /* USER CODE END Task_WaterCtrl */
}


/* USER CODE BEGIN Header_StartTask */
/**
* @brief Function implementing the Start thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask */
void StartTask(void const * argument)
{
  /* USER CODE BEGIN StartTask */
  /* Infinite loop */
  for(;;)
  {
	  if (sm_obj.currentState == ST_WARMUP)
		  HAL_GPIO_TogglePin(LD2_GPIO_Port, BLUE_LD2_Pin); // toggle Blue LED

	  if (sm_obj.currentState == ST_CUPSELECT) {
		  // wait for the cup size selection
		  xEventGroupWaitBits(xEventGroup, EVENTGROUPBIT_CUPSELECT, pdTRUE,
				  pdTRUE, portMAX_DELAY);

		  StateMachine_Run(&sm_obj, EV_CUPSELECT);
	  }

	  osDelay(500);
  }
  /* USER CODE END StartTask */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
