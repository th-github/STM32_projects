/*
 * prototype.c
 *
 *  Created on: Sep 27, 2021
 *      Author: admin
 */


#include "prototype.h"

void proto_TurnOnLED(GPIO_TypeDef* port, uint16_t pin)
{
	HAL_GPIO_WritePin(port, pin, GPIO_PIN_RESET);	// pull up
}
void proto_TurnOffLED(GPIO_TypeDef* port, uint16_t pin)
{
	HAL_GPIO_WritePin(port, pin, GPIO_PIN_SET);		// pull up
}
