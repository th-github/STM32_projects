/*
 * statehandler.c
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#include "main.h"
#include "usart.h"
#include "prototype.h"
#include "statehandler.h"

void Handler_WARMUP(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, BLUE_LD2_Pin, GPIO_PIN_SET); // turn on Blue LED
	startSWTimer(TIMERID_WARMUP);
	usart_vPrintString("warming up, wait ...");
}

void Handler_CHECKWATER(void)
{
	usart_vPrintString("Handler_CHECKWATER");
}

void Handler_CUPSELECT(void)
{
	usart_vPrintString("select cup size to continue ...");
}

void Handler_BREW(void)
{
	usart_vPrintString("start brewing now ...");
	startSWTimer(TIMERID_BREW);
}

void Handler_SERVE(void)
{
	usart_vPrintString("Coffee's ready. Enjoy!");
	usart_vPrintString("New operation begin ...");
}

void Handler_OFF(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, BLUE_LD2_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
	proto_TurnOffLED(GPIOD, LED4OZ_Pin | LED8OZ_Pin | LED12OZ_Pin | LEDBREW_Pin);

	usart_vPrintString("Power shutdown or AutoOff timer expired.");
}

