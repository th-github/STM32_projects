/*
 * usart.c
 *
 *  Created on: Sep 27, 2021
 *      Author: thua
 */


#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include "stm32f7xx_hal.h"
#include "prototype.h"
#include "usart.h"

extern void Error_Handler(void);

#define PVIRTUALUSART	USART3
#define USART_BAUD		115200
static UART_HandleTypeDef h_USART;


UART_HandleTypeDef usart_getusartHandle(void)
{
	return h_USART;
}

/**
  * @brief USART Initialization Function
  * @param None
  * @retval None
  */
UART_HandleTypeDef MX_USART_UART_Init(void)
{

  /* USER CODE BEGIN USART_Init 0 */

  /* USER CODE END USART_Init 0 */

  /* USER CODE BEGIN USART_Init 1 */

  /* USER CODE END USART_Init 1 */

	h_USART.Instance = PVIRTUALUSART;
	h_USART.Init.BaudRate = USART_BAUD;
	h_USART.Init.WordLength = UART_WORDLENGTH_8B;
	h_USART.Init.StopBits = UART_STOPBITS_1;
	h_USART.Init.Parity = UART_PARITY_NONE;
	h_USART.Init.Mode = UART_MODE_TX_RX;
	h_USART.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	h_USART.Init.OverSampling = UART_OVERSAMPLING_16;
	h_USART.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	h_USART.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;

  if (HAL_UART_Init(&h_USART) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART_Init 2 */
  return h_USART;
  /* USER CODE END USART_Init 2 */

}

void usart_vPrintString(char* pvInBuf)
{
	char buf[100];
	snprintf(buf, sizeof(buf), "%s\r\n", pvInBuf);
	HAL_UART_Transmit(&h_USART, (uint8_t*)buf, strlen(buf), 10);
}

