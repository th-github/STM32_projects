/*
 * statehandler.c
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#include "main.h"
#include "statehandler.h"

void Handler_IDLE(void)
{


}
void Handler_WARMUP(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET); // turn on Blue LED
	startSWTimer(TIMERID_WARMUP);
	vPrintString("Handler_WARMUP");
}

void Handler_FILLWATER(void)
{

}

void Handler_CUPSELECT(void)
{
	vPrintString("Handler_CUPSELECT");
}

void Handler_BREW(void)
{
	vPrintString("Handler_BREW");
}

void Handler_SERVE(void)
{

}

void Handler_OFF(void)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
}


