/*
 * statehandler.h
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#ifndef INC_STATEHANDLER_H_
#define INC_STATEHANDLER_H_


void Handler_IDLE(void);
void Handler_WARMUP(void);
void Handler_FILLWATER(void);
void Handler_CUPSELECT(void);
void Handler_BREW(void);
void Handler_SERVE(void);
void Handler_OFF(void);


#endif /* INC_STATEHANDLER_H_ */
