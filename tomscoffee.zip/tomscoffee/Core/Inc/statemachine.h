/*
 * statemachine.h
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 *      The code structure is based on the original author Geoffrey Hunter from blog.mbedded.ninja
 */

#ifndef INC_STATEMACHINE_H_
#define INC_STATEMACHINE_H_

typedef enum {
	ST_IDLE,
	ST_WARMUP,
	ST_FILLWATER,
	ST_CUPSELECT,
	ST_BREW,
	ST_SERVE,
	ST_OFF
} state_t;

typedef struct {
	state_t currentState;
} stateMachine_t;

typedef enum {
	EV_ANY,
	EV_NONE,
	EV_PWRON,
	EV_PWROFF,
	EV_READY,
	EV_WATERTANKEMPTY,
	EV_CUPSELECT,
	EV_BREWDONE,
	EV_TIMEROFF,
} event_t;

void StateMachine_Run(stateMachine_t * operation, event_t event);


#endif /* INC_STATEMACHINE_H_ */
