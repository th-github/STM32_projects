/*
 * statehandler.cpp
 *
 *  Created on: Sep 10, 2021
 *      Author: thua
 */

#include "main.h"
#include "statehandler.h"

void Handler_IDLE(void)
{


}
void Handler_WARMUP(void)
{
	HAL_GPIO_TogglePin(LD1_GPIO_Port, LD1_Pin);
}

void Handler_FILLWATER(void)
{

}

void Handler_CUPSELECT(void)
{

}

void Handler_BREW(void)
{

}

void Handler_SERVE(void)
{

}

void Handler_OFF(void)
{

}


