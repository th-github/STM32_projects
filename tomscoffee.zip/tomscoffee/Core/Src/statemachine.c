/**
  ******************************************************************************
  * @file           : statemachine.c
  * @brief          : define data structure and behavior
  * The code structure is based on the original author Geoffrey Hunter from blog.mbedded.ninja
  ******************************************************************************
*/

#include <statehandler.h>
#include "statemachine.h"

/// represent a group of handlers as a structure so that they can be accessed via pointer
typedef struct {
		void (*fpStateHandler)(void);
} fpStateHandler_t;

// order must be in sync with the order defined in state_t enum for this array index
static fpStateHandler_t  aFPStateHandler[] = {
		{&Handler_IDLE},
		{&Handler_WARMUP},
		{&Handler_FILLWATER},
		{&Handler_CUPSELECT},
		{&Handler_BREW},
		{&Handler_SERVE},
		{&Handler_OFF},
};

typedef struct {
	state_t currentState;
	event_t currentEvent;
	state_t nextState;
} stateTransitionMatrix_t;

static stateTransitionMatrix_t aStateTransitionMatrix[] = {
		{ST_OFF,		EV_NONE, 			ST_OFF},
		{ST_OFF, 		EV_PWRON, 			ST_WARMUP},
		{ST_WARMUP, 	EV_READY, 			ST_CUPSELECT},
		{ST_WARMUP, 	EV_WATERTANKEMPTY, 	ST_FILLWATER},
		{ST_WARMUP, 	EV_PWROFF, 			ST_OFF},
		{ST_CUPSELECT, 	EV_CUPSELECT, 		ST_BREW},
		{ST_BREW, 		EV_BREWDONE, 		ST_SERVE},
		{ST_SERVE, 		EV_TIMEROFF, 		ST_OFF},
		{ST_SERVE, 		EV_NONE, 			ST_IDLE}
};

void StateMachine_Run(stateMachine_t * operation, event_t event)
{
	for (int i = 0; i < (int)(sizeof(aStateTransitionMatrix)/ sizeof(aStateTransitionMatrix[0])); i++)
	{
		if (aStateTransitionMatrix[i].currentState == operation->currentState) {
			if ((aStateTransitionMatrix[i].currentEvent == event) || (aStateTransitionMatrix[i].currentEvent == EV_ANY)) {
				operation->currentState = aStateTransitionMatrix[i].nextState;	// from current state to next state defined in the matrix
				(aFPStateHandler[operation->currentState].fpStateHandler)();	// call the handler associated with the new state just transitioned to
			}
		}
	}
}

